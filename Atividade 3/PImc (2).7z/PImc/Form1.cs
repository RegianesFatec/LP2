﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class FrmIMC : Form
    {
        double Peso, Altura, IMC;
        public FrmIMC()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out Peso))
            {
                MessageBox.Show("Numero 0 Invalido");
                mskbxPeso.Focus();
            }
        }
private void btnCalcular_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
           mskbxResultado.Clear();

        }

        private void mskbxResultado_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            IMC = Peso /(Altura * Altura);
            IMC = Math.Round(IMC, 1);
            mskbxResultado.Text = IMC.ToString();
            if (IMC < 18.5)
                MessageBox.Show("Magreza");
            else if (IMC < 25)
                MessageBox.Show("Normal");
            else if (IMC < 30)
                MessageBox.Show("Sobrepeso");
            else if (IMC < 39.9)
                MessageBox.Show("Obesidade");
            else
                MessageBox.Show("Obesidade Morbida");
        }


        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out Altura))
            {
                MessageBox.Show("Numero 0 Invalido");
                mskbxAltura.Focus();

            }
        }
}
}
