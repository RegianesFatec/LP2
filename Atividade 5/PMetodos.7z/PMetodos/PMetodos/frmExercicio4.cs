﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int contador = 0;// Contador para percorrer o texto
            int contaNum = 0;// Contador para contar os números

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contaNum++;// Conta quantos números há no texto
                }
                contador++;// Incrementa o contador para percorrer o texto
            }

            MessageBox.Show($"O texto tem {contaNum} números");

        }

        private void btnPosicaoCaracter_Click(object sender, EventArgs e)
        {
            int qntdCaracterBranco = 0;// Contador para verificar se há caracter branco no texto
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)// Percorre o texto
            {
                if(char.IsWhiteSpace(rchtxtFrase.Text[i]))// Verifica se o caracter é branco
                {
                    MessageBox.Show($"A posição do primeiro caracter branco é {i+1}");
                    qntdCaracterBranco++;// Incrementa o contador
                    break;// Sai do laço ao encontrar o primeiro caracter branco
                }
            }
            if (qntdCaracterBranco == 0)// Se não houver caracter branco no texto
            {
                MessageBox.Show("Não há caracter branco no texto!");
            }
        }

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;// Contador para contar as letras no texto
            foreach (char c in rchtxtFrase.Text)// Percorre cada caracter do texto
            {
                if(char.IsLetter(c))// Verifica se o caracter é uma letra
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"Há {contaLetra} letras no texto.");
        }

        private void rchtxtFrase_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
