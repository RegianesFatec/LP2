﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int numero1, numero2;// Variáveis para armazenar os números inseridos pelo usuário
            if ( (!int.TryParse(txtNum1.Text, out numero1)) || // Tenta converter o texto da primeira caixa em inteiro
                 (!int.TryParse(txtNum2.Text, out numero2)) ||// Tenta converter o texto da segunda caixa em inteiro
                 (numero1 <= 0) || (numero2 <= 0) || (numero2 < numero1))// Verifica se os números são válidos
            {
                MessageBox.Show("Dados Inválidos!");
                
            } else
            {
                Random objSorteio = new Random();// Cria um objeto da classe Random para gerar números aleatórios
                int i = objSorteio.Next(numero1, numero2);// Gera um número aleatório entre os dois números inseridos pelo usuário
                MessageBox.Show(i.ToString());// Exibe o número sorteado
            }
        }
    }
}
