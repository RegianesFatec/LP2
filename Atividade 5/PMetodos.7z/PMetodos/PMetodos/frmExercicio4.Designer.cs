﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContaNum = new System.Windows.Forms.Button();
            this.btnPosicaoCaracter = new System.Windows.Forms.Button();
            this.btnContaLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Font = new System.Drawing.Font("Footlight MT Light", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchtxtFrase.Location = new System.Drawing.Point(42, 86);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(893, 299);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            this.rchtxtFrase.TextChanged += new System.EventHandler(this.rchtxtFrase_TextChanged);
            // 
            // btnContaNum
            // 
            this.btnContaNum.BackColor = System.Drawing.Color.RosyBrown;
            this.btnContaNum.Font = new System.Drawing.Font("Footlight MT Light", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaNum.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnContaNum.Location = new System.Drawing.Point(42, 440);
            this.btnContaNum.Name = "btnContaNum";
            this.btnContaNum.Size = new System.Drawing.Size(278, 104);
            this.btnContaNum.TabIndex = 1;
            this.btnContaNum.Text = "Conta números";
            this.btnContaNum.UseVisualStyleBackColor = false;
            this.btnContaNum.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnPosicaoCaracter
            // 
            this.btnPosicaoCaracter.BackColor = System.Drawing.Color.RosyBrown;
            this.btnPosicaoCaracter.Font = new System.Drawing.Font("Footlight MT Light", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPosicaoCaracter.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPosicaoCaracter.Location = new System.Drawing.Point(344, 440);
            this.btnPosicaoCaracter.Name = "btnPosicaoCaracter";
            this.btnPosicaoCaracter.Size = new System.Drawing.Size(285, 104);
            this.btnPosicaoCaracter.TabIndex = 2;
            this.btnPosicaoCaracter.Text = "Posição 1º caracter branco";
            this.btnPosicaoCaracter.UseVisualStyleBackColor = false;
            this.btnPosicaoCaracter.Click += new System.EventHandler(this.btnPosicaoCaracter_Click);
            // 
            // btnContaLetras
            // 
            this.btnContaLetras.BackColor = System.Drawing.Color.RosyBrown;
            this.btnContaLetras.Font = new System.Drawing.Font("Footlight MT Light", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaLetras.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnContaLetras.Location = new System.Drawing.Point(657, 440);
            this.btnContaLetras.Name = "btnContaLetras";
            this.btnContaLetras.Size = new System.Drawing.Size(278, 104);
            this.btnContaLetras.TabIndex = 3;
            this.btnContaLetras.Text = "Conta Letras";
            this.btnContaLetras.UseVisualStyleBackColor = false;
            this.btnContaLetras.Click += new System.EventHandler(this.btnContaLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1069, 667);
            this.Controls.Add(this.btnContaLetras);
            this.Controls.Add(this.btnPosicaoCaracter);
            this.Controls.Add(this.btnContaNum);
            this.Controls.Add(this.rchtxtFrase);
            this.Font = new System.Drawing.Font("Footlight MT Light", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "frmExercicio4";
            this.Text = "Exercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContaNum;
        private System.Windows.Forms.Button btnPosicaoCaracter;
        private System.Windows.Forms.Button btnContaLetras;
    }
}