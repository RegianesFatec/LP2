﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");// Remove todas as ocorrências da primeira palavra na segunda
        }// se colocar nada no segundo parâmetro do Replace, ele remove a ocorrência

        private void btnInverte_Click(object sender, EventArgs e)
        {
            char[] vetor = txtPalavra1.Text.ToCharArray();// Converte a string da primeira caixa de texto em um vetor de caracteres
            Array.Reverse(vetor);// Inverte a ordem dos caracteres no vetor

            string auxiliar = new string(vetor); // Converte o vetor de caracteres de volta para string
            txtPalavra2.Text = auxiliar;// Atribui a string invertida à segunda caixa de texto
        }
    }
}
