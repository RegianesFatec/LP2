﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PAluno02
{
    public partial class Form1 : Form
    {
     
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int alunos = 3;
            int notas = 3;
            double somaNotas = 0;
            double media = 0;
            double[,] matrizNotas = new double[alunos, notas];
            string auxiliar = "";
            string saida = "";

            for (int i = 0; i < alunos; i++)
            {
                somaNotas = 0; 
                saida = $"Notas do Aluno {i + 1}:\n";

                for (int j = 0; j < notas; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}:");

                    if (!double.TryParse(auxiliar, out matrizNotas[i, j]))
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                    }
                    else
                    {
                        somaNotas += matrizNotas[i, j];
                        saida += $"Nota {j + 1}: {matrizNotas[i, j]:F2}\n";
                    }
                }

                media = somaNotas / notas;
                saida += $"Média do Aluno {i + 1}: {media:F2}";
                MessageBox.Show(saida);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstboxBanca.Items.Clear();
        }
    }
}
