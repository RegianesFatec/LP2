﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;

namespace PContato0030482321005  
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            try
            {
          
                conexao = new SqlConnection("Data Source=RegiAsus;Initial Catalog=BD;Integrated Security=True;Pooling=False;Encrypt=True;TrustServerCertificate=True");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
        }

        private void cadastroDeContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmContato>().Count() > 0)
            {
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                FrmContato FRMC = new FrmContato();
                FRMC.MdiParent = this;
                FRMC.WindowState = FormWindowState.Maximized;
                FRMC.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form2>().Count() > 0)
            {
                Application.OpenForms["Form2"].BringToFront();
            }
            else
            {
                Form2  FRMC = new Form2 ();
                FRMC.MdiParent = this;
                FRMC.WindowState = FormWindowState.Maximized;
                FRMC.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
