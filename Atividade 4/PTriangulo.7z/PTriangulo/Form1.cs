﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))           
            {
                MessageBox.Show("Valor inválido para o lado A. Por favor, insira um número válido.");
                e.Cancel = false;
            }
        }

        private void txtLadoB_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Valor inválido para o lado B. Por favor, insira um número válido.");
                e.Cancel = false;
            }
        }

        private void txtLadoC_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Valor inválido para o lado C. Por favor, insira um número válido.");
                e.Cancel = false;
            }
        }
            

        private void btnCalculo_Click(object sender, EventArgs e)
        {
            if (ladoA <= 0 || ladoB <= 0 || ladoC <= 0)
            {
                MessageBox.Show("Os lados do triângulo devem ser maiores que zero.");
                return;
            }
            else if (ladoA + ladoB > ladoC && ladoA + ladoC > ladoB && ladoB + ladoC > ladoA)
            {
                if (ladoA == ladoB && ladoB == ladoC)
                {
                    MessageBox.Show("O triângulo é Equilátero.");
                }
                else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                {
                    MessageBox.Show("O triângulo é Isósceles.");
                }
                else
                {
                    MessageBox.Show("O triângulo é Escaleno.");
                }
            }
            else
            {
                MessageBox.Show("Os valores fornecidos não formam um triângulo.");
            }
        }
    

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
