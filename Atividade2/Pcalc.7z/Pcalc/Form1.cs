﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Calculadora : Form
    {
        double numero1, numero2, resultado; //variaveis globais

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNum2, "");
                numero2 = Convert.ToDouble(txtNum2.Text);

            }
            catch
            {
                errorProvider2.SetError(txtNum2, "Numero 2 invalido");
                txtNum2.Focus();
            }
        }


        private void btnadd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResustado.Text = resultado.ToString("G");// G muda o formato do numero
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResustado.Text = resultado.ToString("N");// N muda o formato do numero
        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResustado.Text = resultado.ToString("N");// N muda o formato do numero
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("não pode dividir por zero!!!", "erro",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtResustado.Text = resultado.ToString("G");// G muda o formato do numero
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResustado.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voce quer mesmo sair?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }
            

        public Calculadora()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out numero1))
            {
                errorProvider1.SetError(txtNum1, "Numero 1 invalido");
                txtNum1.Focus();
            }
            else
                errorProvider1.SetError(txtNum1, "");
        }
    }
}
