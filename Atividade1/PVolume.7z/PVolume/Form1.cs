﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Calculo : Form
    {
        double raio, altura, volume;

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura)
             || (altura <= 0))
            {
                MessageBox.Show("Altura invalida");
            }
            /* pode ser tambem separado em 
             else if 
             (altura <=0)
             {MessagemBox.Show("Altura deve ser maior que zero");
            }*/
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtRaio.Text = string.Empty;
            txtVolume.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("Raio invalido");
                txtRaio.Focus();
            }
            else if (!Double.TryParse(txtAltura.Text, out altura)
             || (altura <= 0))
            {
                MessageBox.Show("Altura invalida");
                txtAltura.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        public Calculo()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("Raio invalido");
            }
            
            /* pode ser 
            else if 
            (raio <=0)
            {MessagemBox.Show("Raio deve ser maior que zero");
            }*/
        }
    }
}
