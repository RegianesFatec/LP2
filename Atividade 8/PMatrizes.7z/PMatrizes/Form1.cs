﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];//declaração do vetor com 20 posições
            string auxiliar = "";// Variável para receber o valor da InputBox

            for (int i = 0; i < 20; i++)//laço para preencher o vetor
            {

                auxiliar = Interaction.InputBox($"Digite o número" + $" da posição {i + 1} do vetor:");//solicita o valor para o usuário


                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido! Digite apenas números inteiros.");//mensagem de erro
                    i--;//decrementa o contador para repetir a solicitação
                }
                else
                {
                    auxiliar += $"Vetor[{i}] = {vetor[i]}\n";//concatena os valores na variável de saída
                }
            }
            Array.Reverse(vetor);//inverte a ordem dos valores no vetor

            auxiliar = "Vetor na ordem inversa:\n";//reinicia a variável de saída

            for (int i = 0; i < 20; i++)//laço para percorrer o vetor na ordem inversa
            {
                auxiliar += $"Vetor[{i}] = {vetor[i]}\n";//concatena os valores na variável de saída
            }
            MessageBox.Show(auxiliar);//exibe os valores na ordem inversa
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() {"Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio",
            "Marcelo", "Pedro", "Thais"};//declaração da ArrayList para armazenar os valores

            lista.Remove("Otávio");//remove o nome "Otávio" da lista
            string auxiliar = "";//declaração da variável auxiliar para exibir os nomes

            foreach (string nome in lista)//laço para percorrer a lista
            {
                auxiliar += nome + "\n";//concatena os nomes na variável auxiliar
            }
            MessageBox.Show(auxiliar);//exibe os nomes restantes na lista
        }
        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            int alunos = 3;
            int notas = 3;
            double somaNotas = 0;
            double media = 0;
            double[,] matrizNotas = new double[alunos, notas];
            string auxiliar = "";
            string saida = "";

            for (int i = 0; i < alunos; i++)//laço para percorrer os alunos
            {
                somaNotas = 0; // Zera a soma para o novo aluno
                saida = $"Notas do Aluno {i + 1}:\n";//inicia string de saída para cada aluno

                for (int j = 0; j < notas; j++)//laço para percorrer as notas
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}:");//solicita a nota ao usuário

                    if (!double.TryParse(auxiliar, out matrizNotas[i, j]))//verifica se o valor digitado é um número válido
                    {
                        MessageBox.Show("Valor inválido!");//mensagem de erro
                        j--; // decrementa o contador para repetir a solicitação para a mesma nota
                    }
                    else
                    {
                        somaNotas += matrizNotas[i, j]; // acumula a nota para calcular a média
                        saida += $"Nota {j + 1}: {matrizNotas[i, j]:F2}\n";// concatena a nota na string de saída
                    }
                }

                media = somaNotas / notas; // calcula a média das notas do aluno
                saida += $"Média do Aluno {i + 1}: {media:F2}"; // adiciona a média à string de saída
                MessageBox.Show(saida);
            }
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form2>().Count() > 0)
            {
                Application.OpenForms.OfType<Form2>().First().BringToFront();
            }
            else
            {
                Form2 form2 = new Form2();
                form2.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3>().Count() > 0)
            {
                Application.OpenForms.OfType<Form3>().First().BringToFront();
            }
            else
            {
                Form3 form3 = new Form3();
                form3.Show();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();// fecha formulario.    
        }
    }
}




