﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form3 : Form
    {
        char[] GabaritoRespostas = { 'A', 'C', 'B', 'D', 'A', 'B', 'C', 'D', 'A', 'B' };//gabarito de respostas corretas
        int NumeroQuestoes = 10;//número total de questões
        int UltimoDigitoRA = 5;
        int NumeroAlunos;
        char[,] RespostasAlunos; //matriz para armazenar as respostas dos alunos

        public Form3()
        {
            InitializeComponent();
            NumeroAlunos = (UltimoDigitoRA == 0) ? 2 : UltimoDigitoRA + 1;// Determina o número de alunos com base no último dígito do RA
            RespostasAlunos = new char[NumeroAlunos, NumeroQuestoes];// Inicializa a matriz para armazenar as respostas dos alunos

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            lstboxGabarito.Items.Clear();// Limpa a ListBox antes de exibir novos resultados

            for (int i = 0; i < NumeroAlunos; i++)// 2. Coletar Respostas dos Alunos
            {
                for (int j = 0; j < NumeroQuestoes; j++)// Percorre cada questão para o aluno atual
                {
                    string respostaEntrada;// Variável para armazenar a entrada do usuário
                    bool entradaValida = false;// Flag para validar a entrada

                    do
                    {
                        respostaEntrada = Interaction.InputBox($"Aluno {i + 1}, " +
                            $"digite a resposta da questão {j + 1} (A, B, C, D ou E):");// Solicita a resposta do aluno

                        if (respostaEntrada.Length == 1 && "ABCDE".Contains(respostaEntrada.ToUpper()))// Verifica se a entrada é válida
                        {
                            RespostasAlunos[i, j] = respostaEntrada.ToUpper()[0];// Armazena a resposta na matriz
                            entradaValida = true;// Marca a entrada como válida
                        }
                        else
                        {
                            MessageBox.Show("Resposta inválida! Digite apenas uma letra: A, B, C, D ou E.");
                        }
                    } while (!entradaValida);// Repete até que uma entrada válida seja fornecida
                }
            }

            for (int i = 0; i < NumeroAlunos; i++)// Comparar Respostas e Exibir Resultados
            {
                int contagemAcertos = 0;

                lstboxGabarito.Items.Add(new string('-', 30));// Linha separadora entre alunos
                lstboxGabarito.Items.Add($"Resultados do Aluno {i + 1}:");// Título do bloco do aluno

                for (int j = 0; j < NumeroQuestoes; j++)// Percorre cada questão para o aluno atual
                {
                    char respostaAluno = RespostasAlunos[i, j];// Resposta fornecida pelo aluno
                    char respostaCorreta = GabaritoRespostas[j];// Resposta correta do gabarito
                    string status;// Variável para armazenar o status da resposta

                    if (respostaAluno == respostaCorreta)// Verifica se a resposta do aluno está correta
                    {
                        status = "ACERTO";
                        contagemAcertos++; // Incrementa o total de acertos
                    }
                    else
                    {
                        status = $"ERRO (Sua resposta: {respostaAluno})";// Indica o erro e mostra a resposta do aluno
                    }

                    lstboxGabarito.Items.Add($"  Q{j + 1}: Gab: {respostaCorreta} | {status}");// Exibe o resultado da questão
                }

                lstboxGabarito.Items.Add($"**TOTAL DE ACERTOS: {contagemAcertos} de {NumeroQuestoes}**");// Exibe o total de acertos do aluno
            }
            lstboxGabarito.Items.Add(new string('=', 30));// Linha final de encerramento
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();// fechar   
        }
    }
}
