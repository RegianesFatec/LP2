﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            string[] nomes = new string[10]; //vetor para armazenar os nomes
            int[] tamanho = new int[10];//vetor para armazenar os tamanhos dos nomes
            string auxiliar = "";//variável auxiliar para exibir os resultados

            for (int i = 0; i < 10; i++)//laço para solicitar os nomes
            {
                auxiliar = Interaction.InputBox("Digite o nome" + (i + 1) + ": ");//solicita o nome ao usuário
                if
                    (auxiliar == "")//verifica se o nome está vazio
                    MessageBox.Show("Nome inválido. Digite novamente.");//mensagem de erro
                else
                {
                    nomes[i] = auxiliar; //armazena o nome no vetor
                    tamanho[i] = auxiliar.Replace(" ", "").Length; //armazena o tamanho do nome no vetor, desconsiderando espaços
                }
            }
            for (int i = 0; i < 10; i++)//laço para exibir os resultados
            {
                lstboxNomes.Items.Add($"Nome:  " + nomes[i] + "- Tamanho:  " + tamanho[i] + "caracteres");//adiciona os nomes e seus tamanhos na ListBox

            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstboxNomes.Items.Clear(); //limpa os itens da ListBox  
        }

        private void btnLimpar_Click_1(object sender, EventArgs e)
        {
            lstboxNomes.Items.Clear();//
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();//fecha o formulário
        }
    }
}
